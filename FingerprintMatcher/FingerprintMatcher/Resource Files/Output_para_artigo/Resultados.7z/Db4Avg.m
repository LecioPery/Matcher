close all;
clear;
clc;
x = 0:2000:60000;
xq = 0:0.5:60000;

y01 = [0 0 0 0 0 0 0 0 0 0 0 0 0.00526316 0.0210526 0.157895 0.357895 0.526316 0.684211 0.836842 0.942105 0.968421 0.973684 0.984211 0.994737 1 1 1 1 1 1 1]
y02 = [0 0 0 0 0 0 0 0 0 0 0 0 0.0105263 0.0473684 0.163158 0.368421 0.605263 0.778947 0.873684 0.931579 0.957895 0.973684 0.978947 0.994737 1 1 1 1 1 1 1]
y03 = [0 0 0 0 0 0 0 0 0 0 0 0 0.0105263 0.0263158 0.142105 0.378947 0.668421 0.794737 0.863158 0.926316 0.957895 0.978947 0.989474 0.989474 1 1 1 1 1 1 1]
y04 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0.0421053 0.184211 0.442105 0.642105 0.757895 0.863158 0.921053 0.957895 0.968421 0.973684 0.989474 0.989474 1 1 1 1 1 1]
y05 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0.0210526 0.142105 0.352632 0.584211 0.747368 0.863158 0.936842 0.957895 0.963158 0.978947 0.989474 0.994737 1 1 1 1 1 1]

y0 = (y01 + y02 + y03 + y04 + y05)/5;

y11 = [1 1 1 1 1 0.995 0.98 0.95 0.885 0.715 0.535 0.33 0.15 0.065 0.025 0.01 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]
y12 = [1 1 1 1 1 0.995 0.98 0.95 0.885 0.715 0.535 0.33 0.15 0.065 0.025 0.01 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]
y13 = [1 1 1 1 1 0.995 0.98 0.95 0.885 0.715 0.535 0.33 0.15 0.065 0.025 0.01 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]
y14 = [1 1 1 1 1 0.995 0.98 0.95 0.885 0.715 0.535 0.33 0.15 0.065 0.025 0.01 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]
y15 = [1 1 1 1 1 0.995 0.98 0.95 0.885 0.715 0.535 0.33 0.15 0.065 0.025 0.01 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0]

y1 = (y11 + y12 + y13 + y14 + y15)/5;

yy0 = interp1(x, y0, xq, 'pchip');
yy1 = interp1(x, y1, xq, 'pchip');

% Calculating EER: 
y2 = abs(y0 - y1);
find(y2 == min(y2))
yy2 = abs(yy0 - yy1);
xEER = find(yy2 == min(yy2));
xEERIndex = xq(xEER) % X-axis EER
yEER = yy0(xEER) % Y-axis EER

main = figure
plot(xq, yy0,'-','LineWidth', 2);	hold on
plot(xq, yy1,'--','LineWidth', 2);	hold on
plot([xEERIndex xEERIndex], [0 yEER], 'k--');	hold on
plot([0 xEERIndex], [yEER yEER], 'k--');	hold on
%plot(xEERIndex, yEER, 'bx', 'LineWidth', 10);	hold on
% text(xEERIndex, yEER,strcat('    (', num2str(xEER), ', ', num2str(yEER * 100), ')'))
text(xEERIndex+10*xEERIndex/100, yEER, [num2str(round((10000*yEER))/100) '%'])
legend('False Aceptance', 'False Rejection', 'Location', 'SouthEast')
xlabel('Threshold')
ylabel('Average Equal Error Rate (%)')
set(gca, 'FontSize', 12)
axis([0 60000 0 1])
grid on

print(main, 'Database1_4Main', '-dpng');
FNRxFPR = figure('Color', [1 1 1]);
plot(yy1, yy0, '-', yy1, yy0, 'LineWidth', 2);
hold on
y = -0.1:0.1:1
plot(y, y); 
set(gca, 'FontSize', 12)
xlabel('False Negative')
ylabel('False Positive')
axis([-0.1 1 -0.1 1])
set(gca, 'FontSize', 12)
grid on

print(FNRxFPR, 'Database1_4FNRxFPR','-dpng');