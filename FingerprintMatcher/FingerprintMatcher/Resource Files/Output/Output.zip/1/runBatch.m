function EER = runBatch()
% Adding paths:
addpath('1/1','1/2','1/3','1/4','1/5')

% Running Database's Averages:
%EER{1} = Database1Average();
%EER{2} = Database2Average();
%EER{3} = Database3Average();
%EER{4} = Database4Average();

EERbuffer{1} = 0;
EERbuffer{2} = 0;
EERbuffer{3} = 0;
EERbuffer{4} = 0;
EERbuffer{5} = 0;

% Running 1'th Experiment:
EERbuffer{1} = EERbuffer{1} + Database1_1_MC();
EERbuffer{2} = EERbuffer{2} + Database1_2_MC();
EERbuffer{3} = EERbuffer{3} + Database1_3_MC();
EERbuffer{4} = EERbuffer{4} + Database1_4_MC();
EERbuffer{5} = EERbuffer{5} + Experiment1Average_MC();

% Running 2'th Experiment:
EERbuffer{1} = EERbuffer{1} + Database2_1_MC();
EERbuffer{2} = EERbuffer{2} + Database2_2_MC();
EERbuffer{3} = EERbuffer{3} + Database2_3_MC();
EERbuffer{4} = EERbuffer{4} + Database2_4_MC();
EERbuffer{5} = EERbuffer{5} + Experiment2Average_MC();

% Running 3'th Experiment:
EERbuffer{1} = EERbuffer{1} + Database3_1_MC();
EERbuffer{2} = EERbuffer{2} + Database3_2_MC();
EERbuffer{3} = EERbuffer{3} + Database3_3_MC();
EERbuffer{4} = EERbuffer{4} + Database3_4_MC();
EERbuffer{5} = EERbuffer{5} + Experiment3Average_MC();

% Running 4'th Experiment:
EERbuffer{1} = EERbuffer{1} + Database4_1_MC();
EERbuffer{2} = EERbuffer{2} + Database4_2_MC();
EERbuffer{3} = EERbuffer{3} + Database4_3_MC();
EERbuffer{4} = EERbuffer{4} + Database4_4_MC();
EERbuffer{5} = EERbuffer{5} + Experiment4Average_MC();

% Running 5'th Experiment:
EERbuffer{1} = EERbuffer{1} + Database5_1_MC();
EERbuffer{2} = EERbuffer{2} + Database5_2_MC();
EERbuffer{3} = EERbuffer{3} + Database5_3_MC();
EERbuffer{4} = EERbuffer{4} + Database5_4_MC();
EERbuffer{5} = EERbuffer{5} + Experiment5Average_MC();

EER{1} = EERbuffer{1} / 5;
EER{2} = EERbuffer{2} / 5;
EER{3} = EERbuffer{3} / 5;
EER{4} = EERbuffer{4} / 5;
EER{5} = EERbuffer{5} / 5;

% Removing paths:
rmpath('1/1','1/2','1/3','1/4','1/5')

'Done!'
end