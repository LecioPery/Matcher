clear all
close all
clc

% Guardar todos os resultados
RESULTADOS = zeros(4, 5, 100)

% Iterando nas pastas (experimentos, at� 100)
pasta = 1

% Qual banco est� utilizando (de 1 a 4)
banco = 1

% Em que linha voc� est� (de 1 a 5)
row = 1

% Cria um nome de arquivo com dados, de acordo com o banco e a linha em que est�
name = ['db_' num2str(row) '_' num2str(banco)]

% Executa o comando para carregar os dados (y0 e y1)
eval(name)

% Com os dados carregados, calcula a EER
EER = retEER(y0, y1)

% Armazemar o resultado no respectivo local na matriz de resultados
RESULTADOS(banco, row, pasta) = EER

% Mostrar o resultado rec�m inserido
RESULTADOS(:, :, pasta)
