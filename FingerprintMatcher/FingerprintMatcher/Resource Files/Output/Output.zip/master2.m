RESULTADOS = zeros(4, 5, 100);

numDB = 4;
%numTests = 5;
for j = 1:numDB
	databaseBuffer{j} = 0;
end
totalExecutions = 3;

for i = 1:totalExecutions
	addpath(num2str(i));
	
	currentExecution = runMonteCarlo;
	for j = 1:numDB
		databaseBuffer{j} = databaseBuffer{j} + currentExecution{j};
	end
	
	rmpath(num2str(i));
end

for j = 1:numDB
	databaseBuffer{j} = databaseBuffer{j} / totalExecutions;
end

fileID = fopen('finalchapter.tex', 'w');
fprintf(fileID, '\\chapter{Monte Carlo}\n');
fprintf(fileID, '\\begin{itemize}\n');
for j = 1:numDB
	fprintf(fileID, '\\item ');
	fprintf(fileID, 'Database ');
	fprintf(fileID, num2str(j));
	fprintf(fileID, ': ');
	fprintf(fileID, num2str(databaseBuffer{j}));
	fprintf(fileID, '\n');
end
fprintf(fileID, '\\end{itemize}\n');
fclose(fileID);
movefile('finalchapter.tex', 'LaTeX/chapters/standard');

% Psudoc�digo:
% Enquanto houverem pastas :
%   Entra em uma pasta.
%	   ->Executa os DatabaseXAverage
%	   ->Move os resultados para "pasta"
%   Repete
%   Move todas as pastas para "LaTeX\images\filetype"
